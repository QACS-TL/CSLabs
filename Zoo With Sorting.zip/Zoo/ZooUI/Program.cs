﻿using Zoo;


//Animal animal1 = new Animal("Fido", 5, "Green");

//Animal animal2 = new Animal();

//Animal animal3 = new Animal("Billy") ;

Goat goat1 = new Goat("Gruff", "White") { LimbCount = 4};
Goat goat2 = new Goat("Arnold", "Green") { LimbCount = 2 };
Parrot parrot1 = new Parrot("Tim", "Red", "Pieces of eight ") { LimbCount = 5 };
Parrot parrot2 = new Parrot("Polly", "Blue", "Pieces of eight ") { LimbCount = 3 };
Fly freddie = new Fly();
//goat1.Name = "Gruff";
//goat1.LimbCount = 4;
//goat1.Colour = "White";

Console.WriteLine(goat1.Move("Up"));
Console.WriteLine(goat1.Eat("trousers"));

Console.WriteLine(goat1.Butt("Fido"));

Console.WriteLine(parrot1.Talk(4));

//animal1.Name = "Rover";
//animal1.SetLimbCount(4);
//animal1.LimbCount = 4;
//animal1.Colour = "Brown";

//int newLimbCount = -1;
//animal2.Name = "Fifi";

//animal2.SetLimbCount(newLimbCount);
//animal2.LimbCount = newLimbCount;
//animal2.Colour = "Pink";


//Console.WriteLine(animal2.LimbCount);
//Console.WriteLine(animal1.Eat("Biscuits"));
//Console.WriteLine(animal2.Eat("Cheese"));

//Console.WriteLine(animal1.Move("North"));
//Console.WriteLine(animal2.Move(15));

IVegetable veg = new Carrot("Purple") { Length = 10, Name = "Colin" };

Console.WriteLine($" {Animal.GetCount()} ");

List<Animal> zoo = new List<Animal>();
//zoo.Add(animal1);
//zoo.Add(animal2);
//zoo.Add(animal3);
//zoo.Add(new Animal("Zoe", 2, "Black & White"));
zoo.Add(goat1);
zoo.Add(parrot1);
//zoo.Add(new Fly());
zoo.Add(goat2);
zoo.Add(parrot2);

//Feeding Time
foreach (Animal a in zoo)
{
    //if (a is not Fly)
    //{
    //    Console.WriteLine(a.Eat("peanuts"));
    //}
    //if (a is Goat)
    //{
    //    Console.WriteLine(((Goat)a).Butt("Zoe"));
    //}
    //else if (a is Parrot)
    //{
    //    Console.WriteLine(((Parrot)a).Talk(2));
    //}
    //Parrot p = a as Parrot;
    //if ( p != null)
    //{
    //    Console.WriteLine(((Parrot)p).Talk(1));
    //}
    Console.WriteLine(a.ToString());
}

//Limbcount sequence
Console.WriteLine("LimbCount Sequence");
zoo.Sort();

foreach (Animal a in zoo)
{
    Console.WriteLine(a.ToString());
}

//zoo.Sort(new AnimalColourComparer());
Console.WriteLine("Colour Sequence");
zoo.Sort(Animal.GetAnimalColourComparer);

foreach (Animal a in zoo)
{
    Console.WriteLine(a.ToString());
}

Console.WriteLine("Name Sequence");
zoo.Sort(Animal.GetAnimalNameComparer);

foreach (Animal a in zoo)
{
    Console.WriteLine(a.ToString());
}






