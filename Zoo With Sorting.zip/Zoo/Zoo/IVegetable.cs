﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zoo
{
    public interface IVegetable
    {
        string Name { get; set; }
        int Length {  get; set; }
        string Colour { get; }

        string Grow(int increment);


    }
}
