﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zoo
{
    public class Carrot : IVegetable
    {
        public Carrot(string colour)
        {
            this.Colour = colour; 
        }

        public string Name { get; set; }
        private int length;
        public int Length {
            get => length;
            set {
                if (value < 0)
                    value = 0;
                length = value; 
            }
        }

        public string Colour { get; private set; } = "Orange";

        public string Grow(int increment)
        {
            if (increment < 0)
                return string.Empty;
            length += increment;
            return $"I'm a carrot and I am now {Length}mm long";
        }
    }
}
