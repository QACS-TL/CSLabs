﻿namespace Zoo
{
    public abstract class Animal: IComparable<Animal>
    {
        //public string name;
        public string Name { private get; set; }
        private int limbCount;
        public string Colour { get; set; }
        public static int Count { get; set; } = 0;

        public Animal(string name, int limbCount, string colour )
        {
            this.Name = name;
            this.LimbCount = limbCount;
            this.Colour = colour;
            Count++;

        }


        public Animal(string name):this(name, 6, "yellow")
        {
            //this.Name = "name";
            //this.LimbCount = 6;
            //this.Colour = "yellow";
        }


        public Animal(): this("Anonymous")
        {
            //this.Name = "Anonymous";
            //this.LimbCount = 6;
            //this.Colour = "yellow";
        }

        //public int GetLimbCount()
        //{
        //    return limbCount;
        //}

        //public void SetLimbCount(int value)
        //{
        //    if (value < 0)
        //    {
        //        value = 0;
        //    }
        //    limbCount = value;
        //}


        public int LimbCount
        {
            get 
            { 
                return limbCount; 
            }
            set 
            {
                if (value < 0)
                {
                    value = 0;
                }
                limbCount = value; 
            }
        }


        public string Move(int distance, int direction)
        {
            return $"I'm an animal called {Name} using some of my {limbCount} limbs to move {direction} degrees for {distance} metres ";
        }

        public string Move(int distance)
        {
            return $"I'm an animal called {Name} using some of my {limbCount} limbs to move {distance} metres ";
        }

        public string Move(string direction)
        {
            return $"I'm an animal called {Name} using some of my {limbCount} limbs to move {direction}  ";
        }

        public abstract string Eat(string food);
        //{
        //    return $"I'm an {Colour} animal called {Name} using some of my {limbCount} limbs to eat {food} ";
        //}

        public static string GetCount()
        {
            return $"There are currently {Count} animals";
        }

        public string ToString()
        {
            return $"I'm an {Colour} animal called {Name} and I have {LimbCount} limbs.";
        }

        public int CompareTo(Animal? other)
        {
            return this.LimbCount.CompareTo(other.LimbCount);
        }

        private static IComparer<Animal> animalColourComparer = null;

        public static IComparer<Animal> GetAnimalColourComparer
        {
            get
            {
                if (animalColourComparer == null)
                {
                    animalColourComparer = new AnimalColourComparer();
                }
                return animalColourComparer;
            }
        }
        private class AnimalColourComparer : IComparer<Animal>
        {
            public int Compare(Animal? x, Animal? y)
            {
                return x.Colour.CompareTo(y.Colour);
            }
        }


        private static IComparer<Animal> animalNameComparer = null;

        public static IComparer<Animal> GetAnimalNameComparer
        {
            get
            {
                if (animalNameComparer == null)
                {
                    animalNameComparer = new AnimalNameComparer();
                }
                return animalNameComparer;
            }
        }
        private class AnimalNameComparer : IComparer<Animal>
        {
            public int Compare(Animal? x, Animal? y)
            {
                return x.Name.CompareTo(y.Name);
            }
        }
    }
}
