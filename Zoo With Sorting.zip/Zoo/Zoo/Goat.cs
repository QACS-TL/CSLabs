﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zoo
{
    public class Goat:Animal
    {
        public int HornLength { get; set; } = 15;
        public Goat(string name, string colour):base(name, 4, colour)
        {
            
        }

        public string Butt(string thing)
        {
            return $"I'm a GOAT headbutting {thing} with my horns that are {HornLength}cm long.";
        }

        public override string Eat(string food)
        {
            return $"I'm a {Colour} GOAT eating everything in my path including {food}";
        }

    }
}
