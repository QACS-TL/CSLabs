using System;

namespace Interfaces {

    public interface IConsumable {
        string DescribeTaste();
        string IsMainCourseDish();
    }
}
