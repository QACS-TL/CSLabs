using System;
using System.Collections.Generic;
using System.Text;
using Interfaces;

namespace LibraryTypes {
    public class Fish : IConsumable, IInsurable {

        public string Name { get; private set; }

        public Fish(string name) {
            Name = name;
        }

        #region IConsumable Members

        public string DescribeTaste() {
            return Name + ": Quite fishy";
        }

        public string IsMainCourseDish() {
            return Name + ": True";
        }

        #endregion

        #region IInsurable Members

        public string GetPremium() {
            return Name + ": " + "10 pounds";
        }

        public string Expires() {
            return Name + ": " + DateTime.Now.ToShortDateString();
        }

        #endregion
    }

}
