using System;
using Interfaces;

namespace LibraryTypes {
    public abstract class Bird : IConsumable {

        protected string Name { get; private set; }

        public Bird(string name) {
            Name = name;
        }


        public virtual string DescribeTaste() {
            return Name + ": " + "Delicate";
        }

        public virtual string IsMainCourseDish() {
            return Name + ": " + true;
        }
    }
}
