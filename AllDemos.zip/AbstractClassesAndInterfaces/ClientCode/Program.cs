using System;
using System.Collections;
using LibraryTypes;
using Interfaces;

namespace ClientCode {
    class Program {
        static void Main(string[] args) {
            object[] things = { 
                          new Penguin("Pingu"), 
                          new Duck("Donald"), 
                          new Fish("Freddie") 
                        };

            Console.WriteLine("### These are Consumable ###");

            foreach (object o in things)
            {
                if (o is IConsumable)
                {
                    IConsumable ic = (IConsumable)o;
                    Console.WriteLine(ic.DescribeTaste() + ",\t" + ic.IsMainCourseDish());
                }
            }

            Console.WriteLine("\n### These are Insurable ###");
            foreach (object o in things)
            {
                if (o is IInsurable)
                {
                    IInsurable ii = (IInsurable)o;
                    Console.WriteLine(ii.GetPremium() + ",\t" + ii.Expires());
                }
            }
            Console.WriteLine();
        }
    }
}
