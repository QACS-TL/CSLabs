﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    public class Dog:Animal
    {
        public override string Eat(string food)
        {
            return $"I'm a dog called {name} slobbering on {food}.";
        }

        public string Bark()
        {
            return "Woof!";
        }
    }

    public class Poodle:Dog
    {
        
    }

}
