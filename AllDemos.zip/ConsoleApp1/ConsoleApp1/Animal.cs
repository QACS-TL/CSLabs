﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    public class Animal
    {
        public string name = "Anon";
        public int age = 0;
        public static int count = 0;

        public Pet pet = new Pet();
        public Animal()
        {
            pet.petType = "Fish";
            Count();
        }

        public static int Count()
        {
            count++;
            return count;
        }

        public virtual string Eat(string food)
        {
            return $"I'm an animal called {name} eating {food}.";
        }

        public virtual string Eat(int number)
        {
            return $"I'm an animal called {name} eating {number} bits of food.";
        }

        public virtual string Eat(string food, string drink)
        {
            return $"I'm an animal called {name} eating {food} and drinking {drink}.";
        }

        public override string ToString()
        {
            return $"My name is {name} and I am {age} years old.";
        }
    }
}
