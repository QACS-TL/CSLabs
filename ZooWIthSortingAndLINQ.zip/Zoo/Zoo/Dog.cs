﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zoo
{
    internal class Dog : Animal
    {
        public Dog(string name="Fifi")
        {
            this.Name = name;
        }

        public string Bark(int numberOfTimes = 5)
        {
            string message = string.Empty;
            for (int i = 0; i < numberOfTimes; i++)
            {
                message += "Woof, ";
            }
            return message;
        }
        public override string Eat(string food)
        {
            return $"I'm a DOG called {Name} using some of my {LimbCount} limbs to slobbers over {food}";
        }
    }
}
