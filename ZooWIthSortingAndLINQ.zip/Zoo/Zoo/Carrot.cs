﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zoo
{
    internal class Carrot : IVegetable
    {
        public string Name { get; set;  }

        public string Colour { get; set; }

        private int currentSize = 0;

        public string Grow(int rate)
        {
            currentSize += rate;
            return $"I'm a carrot and I am now {currentSize} cm long";
        }
    }
}
