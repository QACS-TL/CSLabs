﻿namespace Zoo
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            AnotherMethod();

            List<Animal> animals = new List<Animal>();

            Animal animal1 = new Dog("Rover");

            //animal1.Name = "Rover";
            animal1.Age = 21;
            animal1.LimbCount = 4;
            animals.Add(animal1);

            Animal animal2 = new Spider() { Name= "Boris", LimbCount=8 };
            //animal2.Name = "Boris";
            animal2.Age = 15;
            animal2.LimbCount = -1;
            animals.Add(animal2);

            animals.Add(new Lion() { Name="Leo", Age = 10, LimbCount = 4 });
            Console.WriteLine(animals[2].Eat("Cheese"));

            Console.WriteLine(animal2.LimbCount);

            Console.WriteLine(animal1.Move("North", 12));
            Console.WriteLine(animal2.Move("East", 0.4f));

            animals.Add(new Dog() { LimbCount=6});

            Dog dog = new Dog() { Age = 4, LimbCount = 2 };
            animals.Add(dog);

            Console.WriteLine(dog.Bark(6));
            Dragon dragon = new Dragon() { Name = "Pete", Age = 123, LimbCount = 3 };
            Console.WriteLine(dragon.Eat("maiden"));


            animals.Add(dragon);

            Console.WriteLine($"There are currently {Animal.AnimalCount} animals");

            foreach (Animal animal in animals)
            {
                Console.WriteLine(animal.Eat("Lettuce"));
                if (animal.GetType() == typeof(Dog))
                {
                    Console.WriteLine(((Dog)animal).Bark(7));
                }
                if (animal.GetType() == typeof(Dragon))
                {
                    Console.WriteLine(((Dragon)animal).BreatheFire(Intensity.Hot));
                }
            }

            animals.Sort();

            foreach(Animal animal in animals)
            {
                Console.WriteLine(animal.Eat("Bananas"));
            }

            animals.Sort(Animal.AnimalNameComparer);

            Console.WriteLine("************************************");
            foreach (Animal animal in animals)
            {
                Console.WriteLine(animal.Eat("Bananas"));
            }


            animals.Sort(Animal.AnimalAgeComparer);

            Console.WriteLine("************************************");
            foreach (Animal animal in animals)
            {
                Console.WriteLine($"{animal.Eat("Popcorn")} and I am {animal.Age} years old");
            }

            List<Animal> animalsInNameSequence = animals.OrderBy(a => a.Name).ToList();

            Console.WriteLine("************************************");
            foreach (Animal animal in animalsInNameSequence)
            {
                Console.WriteLine($"{animal.Eat("Crisps")} and I am {animal.Age} years old");
            }


            List<Animal> animalsInNameSequenceWithMoreThan2Limbs = animals.Where(a => a.LimbCount > 2).OrderBy(a => a.Name).ToList();

            Console.WriteLine("************************************");
            foreach (Animal animal in animalsInNameSequenceWithMoreThan2Limbs)
            {
                Console.WriteLine($"{animal.Eat("Crisps")} and I am {animal.Age} years old");
            }

            var animalsInNameSequenceWithMoreThan2Limbsx = animals.Where(a => a.LimbCount > 2).OrderByDescending(a => a.Name).Select(a =>   a.Name ).ToList();

            Console.WriteLine("************************************");
            foreach (var animal in animalsInNameSequenceWithMoreThan2Limbsx)
            {
                Console.WriteLine($"{animal}");
            }
            IVegetable carrot = new Carrot() { Name="Cressida", Colour="Orange" };
        }

        public static string AnotherMethod()
        {
            return "Hello";
        }
    }
}