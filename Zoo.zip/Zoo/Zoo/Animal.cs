﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zoo
{
    public class Animal
    {
        public string name;
        public int age;
        private int limbCount;

        //public void SetLimbCount(int limbCount)
        //{
        //    if (limbCount < 0)
        //    {
        //        limbCount = 0;
        //    }
        //    if (limbCount > 1000)
        //    {
        //        limbCount = 1000;
        //    }
        //    this.limbCount = limbCount;
        //}

        //public int GetLimbCount()
        //{
        //    return this.limbCount;
        //}

        public int LimbCount
        {
            get 
            { 
                return this.limbCount; 
            }
            set
            {
                if (value < 0)
                {
                    value = 0;
                }
                if (value > 1000)
                {
                    value = 1000;
                }
                this.limbCount = value; 
            }
        }

        public string Move(string direction, float distance)
        {
            return $"I'm an animal called {name} using some of my {limbCount} limbs to move {direction} for {distance} metres";
        }
        public string Eat(string food)
        {
            return $"I'm an animal called {name} using some of my {limbCount} limbs to eat {food}";
        }
    }
}
