﻿namespace Zoo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Animal animal1 = new Animal();
            animal1.name = "Rover";
            animal1.age = 2;
            animal1.LimbCount = 4;

            Animal animal2 = new Animal();
            animal2.name = "Boris";
            animal2.age = 5;
            animal2.LimbCount = -1;

            Console.WriteLine(animal2.LimbCount);

            Console.WriteLine(animal1.Move("North", 12));
            Console.WriteLine(animal2.Move("East", 0.4f));
        }
    }
}