﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zoo
{
    public class Parrot: Animal
    {
        public int BeakSize { get; set; } = 5;
        public string Message { get; set; }

        public Parrot(string name, string colour, string message) : base(name, 4, colour)
        {
            this.Message = message;
        }

        public string Talk(int number)
        {
            string text = "";
            for (int i = 0; i < number; i++) {
                text += Message;
            }
            return $"I'm a PARROT and here's what I've go to say '{text}'";
        }

        public override string Eat(string food)
        {
            return  $" I'm a {Colour} PARROT cracking open and eating {food}";
        }
    }
}
