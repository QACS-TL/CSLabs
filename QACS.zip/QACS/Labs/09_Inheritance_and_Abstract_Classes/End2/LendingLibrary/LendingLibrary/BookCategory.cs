﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LendingLibrary
{
    public enum BookCategory
    {
        Children,
        Adult
    }
}
