﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyCarWebAppo.Models
{
    public class Spider : Animal
    {
        public override string Eat(string food)
        {
            return $"I'm a SPIDER called {Name} using some of my {LimbCount} limbs to tie up my {food} and I'll eat it later";
        }
    }
}
