﻿namespace MyCarWebAppo.Models
{
    public class AnimalsRepository
    {
        List<Animal> animals = new List<Animal>()
            {
                new Dog{Id=1, Name="Timmy", Age=6, LimbCount=4},
                new Spider{Id=2, Name="Snider", Age=1, LimbCount=8},
                new Dragon{Id=3, Name="Puff", Age=101, LimbCount=7},
                new Lion{Id=4, Name="Clarence", Age=16, LimbCount=3},
                new Dog{Id=5, Name="Wuffles", Age=7, LimbCount=5},
                new Dragon{Id=6, Name="Dylan", Age=3, LimbCount=6}
            };

        public List<Animal> GetAllAnimals()
        {
            return animals;
        }
    }
}
