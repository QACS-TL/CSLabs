﻿namespace Zoo
{
    public class Animal
    {
        //public string name;
        public string Name { private get; set; }
        private int limbCount;
        public string Colour { get; set; }
        public static int Count { get; set; } = 0;

        public Animal(string name, int limbCount, string colour )
        {
            this.Name = name;
            this.LimbCount = limbCount;
            this.Colour = colour;
            Count++;

        }


        public Animal(string name):this(name, 6, "yellow")
        {
            //this.Name = "name";
            //this.LimbCount = 6;
            //this.Colour = "yellow";
        }


        public Animal(): this("Anonymous")
        {
            //this.Name = "Anonymous";
            //this.LimbCount = 6;
            //this.Colour = "yellow";
        }

        //public int GetLimbCount()
        //{
        //    return limbCount;
        //}

        //public void SetLimbCount(int value)
        //{
        //    if (value < 0)
        //    {
        //        value = 0;
        //    }
        //    limbCount = value;
        //}


        public int LimbCount
        {
            get 
            { 
                return limbCount; 
            }
            set 
            {
                if (value < 0)
                {
                    value = 0;
                }
                limbCount = value; 
            }
        }


        public string Move(int distance, int direction)
        {
            return $"I'm an animal called {Name} using some of my {limbCount} limbs to move {direction} degrees for {distance} metres ";
        }

        public string Move(int distance)
        {
            return $"I'm an animal called {Name} using some of my {limbCount} limbs to move {distance} metres ";
        }

        public string Move(string direction)
        {
            return $"I'm an animal called {Name} using some of my {limbCount} limbs to move {direction}  ";
        }

        public string Eat(string food)
        {
            return $"I'm an {Colour} animal called {Name} using some of my {limbCount} limbs to eat {food} ";
        }

        public static string GetCount()
        {
            return $"There are currently {Count} animals";
        }
    }
}
