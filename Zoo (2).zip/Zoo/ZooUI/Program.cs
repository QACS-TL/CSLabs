﻿using Zoo;


Animal animal1 = new Animal("Fido", 5, "Green");

Animal animal2 = new Animal();

Animal animal3 = new Animal("Billy") ;

//animal1.Name = "Rover";
//animal1.SetLimbCount(4);
animal1.LimbCount = 4;
//animal1.Colour = "Brown";

//int newLimbCount = -1;
//animal2.Name = "Fifi";

//animal2.SetLimbCount(newLimbCount);
//animal2.LimbCount = newLimbCount;
//animal2.Colour = "Pink";


Console.WriteLine(animal2.LimbCount);
Console.WriteLine(animal1.Eat("Biscuits"));
Console.WriteLine(animal2.Eat("Cheese"));

Console.WriteLine(animal1.Move("North"));
Console.WriteLine(animal2.Move(15));

Console.WriteLine($" {Animal.GetCount()} ");

Console c = new Console();
