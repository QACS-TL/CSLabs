﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyCarWebAppo.Models
{
    enum Intensity{
        Cool,
        Medium,
        Hot,
        Incendury
    }
    internal class Dragon:Animal
    {
        private Intensity intensity = Intensity.Cool;
        public string BreatheFire(Intensity intensity)
        {
            this.intensity = intensity;
            return $"I'm a Dragon called {Name} breathing a {intensity} flame!";
        }

        public override string Eat(string food)
        {
            return $"I'm a DRAGON called {Name} using some of my {LimbCount} limbs to bake my {food} with a flame intesity of {intensity}";
        }

    }
}
