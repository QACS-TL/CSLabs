﻿using MyCarWebAppo.Models;

namespace MyCarWebAppo.Models
{
    public class CarsRepository
    {
        List<Car> cars = new List<Car>()
        {
            new Car {Id=1, Registration="ABC 123", Make="Ford", Model="Fiesta", MaxSpeed=120},
            new Car {Id=2, Registration="ABC 456", Make="Ford", Model="Mondeo", MaxSpeed=120},
            new Car { Id = 3, Registration = "DEF 123", Make = "Audi", Model = "A6", MaxSpeed = 140 },
            new Car { Id = 4, Registration = "DEF 456", Make = "Ford", Model = "Ka", MaxSpeed = 100 },
        };

        public List<Car> GetAllCars()
        {
            return cars;
        }
    }
}
