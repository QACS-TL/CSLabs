﻿using System.Runtime.CompilerServices;

namespace BankAccounts
{
    public abstract class Account
    {
        // interest rate (static) - Property

        //Create CalcInterest function

        // create and chain constructor

        // introduce overdraft limit

        //public static decimal InterestRate { get; set; } = 0.05M;
       

        public Account(string name, string accountNumber) :this(name, accountNumber, 0)
        {
            
        }

        public Account(string name, string accountNumber, decimal balance) 
        {
            this.name = name;
            this.accountNumber = accountNumber;
            Balance = balance;
        }

        private string name = "Anonymous";

        public string Name
        {
            get { return name; }
            set
            {
                if (name.Length <= 1)
                {
                    return;
                }
                name = value;
            }
        }

        private string accountNumber = "XXXXXX";

        public string AccountNumber
        {
            get { return accountNumber; }
            set
            {
                if (accountNumber.Length != 6)
                {
                    return;
                }
                accountNumber = value;
            }
        } 

        public decimal balance = 0;

        public decimal Balance
        {
            get { return balance; }
            set
            {
                if (value < 0)
                {
                    value = 0;
                }
                balance = value;
            }
        }

        public decimal Credit(decimal amount)
        {
            Balance += amount;
            return Balance;
        }

        public virtual decimal Debit(decimal amount)
        {
            Balance -= amount;
            return Balance;
        }





    }
}
