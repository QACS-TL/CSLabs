﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MyCarWebAppo.Models;

namespace MyCarWebAppo.Controllers
{
    public class CarsController : Controller
    {
        CarsRepository carsRepository;

        public CarsController()
        {
            carsRepository = new CarsRepository();
        }

        // GET: CarsController
        public ActionResult Index()
        {
            List<Car> cars = carsRepository.GetAllCars();
            return View(cars);
        }

        // GET: CarsController/Details/5
        public ActionResult Details(int id)
        {
            Car car = carsRepository.GetCarById(id);
            return View(car);
        }

        // GET: CarsController/Create
        public ActionResult Create()
        {
            Car car = new Car();
            return View(car);
        }

        // POST: CarsController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Car car)
        {
            try
            {
                carsRepository.CreateCar(car);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View(car);
            }
        }

        // GET: CarsController/Edit/5
        public ActionResult Edit(int id)
        {
            Car car = carsRepository.GetCarById(id);
            return View(car);
        }

        // POST: CarsController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, Car car)
        {
            try
            {
                carsRepository.UpdateCar(car);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View(car);
            }
        }

        // GET: CarsController/Delete/5
        public ActionResult Delete(int id)
        {
            Car car = carsRepository.GetCarById(id);
            return View(car);
        }

        // POST: CarsController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                carsRepository.DeleteCar(id);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                Car car = carsRepository.GetCarById(id);
                return View(car);
            }
        }
    }
}
