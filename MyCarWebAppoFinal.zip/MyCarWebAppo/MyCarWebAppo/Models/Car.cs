﻿using System.ComponentModel.DataAnnotations;

namespace MyCarWebAppo.Models
{
    public class Car
    {
        public int Id { get; set; }
        public string Registration { get; set; }
        public string Make { get; set; }
        [MinLength(5)]
        public string Model { get; set; }
        [Required]
        [Range(50, 240)]
        public int MaxSpeed { get; set; }

    }
}
