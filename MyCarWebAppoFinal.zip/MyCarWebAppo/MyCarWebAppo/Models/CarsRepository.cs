﻿using CsvHelper;
using MyCarWebAppo.Models;
using System.Globalization;

namespace MyCarWebAppo.Models
{
    public class CarsRepository
    {
        List<Car> cars = new List<Car>();
        //{
        //    new Car { Id=1, Registration="ABC 123", Make="Ford", Model="Fiesta", MaxSpeed=120},
        //    new Car { Id=2, Registration="ABC 456", Make="Ford", Model="Mondeo", MaxSpeed=120},
        //    new Car { Id = 3, Registration = "DEF 123", Make = "Audi", Model = "A6", MaxSpeed = 140 },
        //    new Car { Id = 4, Registration = "DEF 456", Make = "Ford", Model = "Ka", MaxSpeed = 100 },
        //};
        public CarsRepository()
        {
            using (StreamReader sr = new StreamReader(@"Models/cars.csv"))
            using (CsvReader reader = new CsvReader(sr, CultureInfo.InvariantCulture))
            {
                cars = reader.GetRecords<Car>().ToList();
            }
        }

        public List<Car> GetAllCars()
        {
            return cars;
        }

        public Car GetCarById(int id)
        {
            return cars.SingleOrDefault(c => c.Id == id);
        }

        public void CreateCar(Car car)
        {
            cars.Add(car);
            SaveCars();
        }

        public void UpdateCar(Car car)
        {
            Car originalCar = cars.SingleOrDefault(c => c.Id == car.Id);
            if (originalCar != null)
            {
                originalCar.Model = car.Model;
                originalCar.Make = car.Make;
                originalCar.MaxSpeed = car.MaxSpeed;
                originalCar.Registration = car.Registration;
            }
            SaveCars();
        }
        public void DeleteCar(int id)
        {
            Car car = cars.SingleOrDefault(c => c.Id == id);
            cars.Remove(car);
            SaveCars();
        }

        private void SaveCars()
        {
            using (StreamWriter sw = new StreamWriter(@"Models/cars.csv"))
            using (CsvWriter writer = new CsvWriter(sw, CultureInfo.InvariantCulture))
            {
                writer.WriteRecords(cars);
            }
        }
    }
}
