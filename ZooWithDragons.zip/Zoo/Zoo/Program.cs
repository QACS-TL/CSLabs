﻿namespace Zoo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<Animal> animals = new List<Animal>();

            Animal animal1 = new Animal("Rover");
            //animal1.Name = "Rover";
            animal1.Age = 2;
            animal1.LimbCount = 4;
            animals.Add(animal1);

            Animal animal2 = new Animal("Boris");
            //animal2.Name = "Boris";
            animal2.Age = 5;
            animal2.LimbCount = -1;
            animals.Add(animal2);

            animals.Add(new Animal("Leo") { Age=5, LimbCount=4 });
            Console.WriteLine(animals[2].Eat("Cheese"));

            Console.WriteLine(animal2.LimbCount);

            Console.WriteLine(animal1.Move("North", 12));
            Console.WriteLine(animal2.Move("East", 0.4f));

            animals.Add(new Animal());

            Dog dog = new Dog() { Age=7, LimbCount=3 };
            animals.Add(dog);

            Console.WriteLine(dog.Bark(6));
            Dragon dragon = new Dragon() { Name="Pete", Age=123, LimbCount= 6 };
            Console.WriteLine(dragon.Eat("maiden"));


            animals.Add(dragon);

            foreach (Animal animal in animals) 
            {
                Console.WriteLine(animal.Eat("Lettuce"));
                if (animal.GetType() == typeof(Dog))
                {
                    Console.WriteLine(((Dog)animal).Bark(7));
                }
                if (animal.GetType() == typeof(Dragon))
                {
                    Console.WriteLine(((Dragon)animal).BreatheFire(Intensity.Hot));
                }
            }
        }
    }
}