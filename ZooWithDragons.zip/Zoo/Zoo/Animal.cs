﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zoo
{
    public class Animal
    {
        //public Animal():this("Anon")
        //{

        //}

        public Animal(string name="Anon")
        {
            Name = name;
            Age = 1;
            LimbCount = 100;
        }

        public string name;
        public string Name { get; set; }
        private int age;

        public int Age
        {
            get { return age; }
            set 
            {
                if (value < 0)
                    value = 0;
                if (value > 200)
                    value = 200;
                age = value; 
            }
        }


        private int limbCount;

        //public void SetLimbCount(int limbCount)
        //{
        //    if (limbCount < 0)
        //    {
        //        limbCount = 0;
        //    }
        //    if (limbCount > 1000)
        //    {
        //        limbCount = 1000;
        //    }
        //    this.limbCount = limbCount;
        //}

        //public int GetLimbCount()
        //{
        //    return this.limbCount;
        //}

        public int LimbCount
        {
            get 
            { 
                return this.limbCount; 
            }
            set
            {
                if (value < 0)
                {
                    value = 0;
                }
                if (value > 1000)
                {
                    value = 1000;
                }
                this.limbCount = value; 
            }
        }

        public string Move(string direction, float distance)
        {
            return $"I'm an animal called {Name} using some of my {LimbCount} limbs to move {direction} for {distance} floating metres";
        }

        public string Move(string direction, int distance)
        {
            return $"I'm an animal called {Name} using some of my {LimbCount} limbs to move {direction} for {distance} whole metres";
        }

        public virtual string Eat(string food)
        {
            return $"I'm an animal called {Name} using some of my {LimbCount} limbs to eat {food}";
        }
    }
}
