using CarLibrary;

namespace CarLibraryTests
{
    public class CarTests
    {
        [Fact]
        public void Test1()
        {
            Car c1 = new Car();
            c1.Make = "Ford";
            Assert.Equal("c1", nameof(c1));
            Assert.Equal("Ford", c1.Make);
            Assert.Equal("Unknown Model", c1.Model);
        }

        [Fact]
        public void Test2()
        {
            Car c2 = new Car("Audi", "TT");
            c2.Colour = "Red";
            c2.Speed = 30;
            Assert.Equal("Audi", c2.Make);
            Assert.Equal("TT", c2.Model);
            Assert.Equal("Red", c2.Colour);
            Assert.Equal(30, c2.Speed);
            Assert.Equal(48.28, Math.Round(c2.SpeedInKilometres, 2));
        }


        [Fact]
        public void Test3()
        {
            Car c3 = new Car("BMW", "X5") { Colour = "Grey", RegistrationNumber = "ABC 123" };
            Assert.Equal("BMW", c3.Make);
            Assert.Equal("X5", c3.Model);
            Assert.Equal("Grey", c3.Colour);
            Assert.Equal("ABC 123", c3.RegistrationNumber);
        }


        [Fact]
        public void Test4()
        {
            Car c4 = new Car();
            Assert.Equal("Unknown Make", c4.Make);
            Assert.Equal("Unknown Model", c4.Model);
            Assert.Equal("White", c4.Colour);
            Assert.Null(c4.RegistrationNumber);
        }

    }
}